#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

typedef struct block_unit {
  size_t size;
  struct block_unit * next;
  struct block_unit * prev;
} block;

block * head = NULL;
block * tail = NULL;

unsigned long total_size = 0;
unsigned long free_size = 0;

//First Fit
void * ff_malloc(size_t size);
void ff_free(void * ptr);

//Best Fit
void * bf_malloc(size_t size);
void bf_free(void * ptr);

//Allocate requeted memory.
void * allocate_mem(size_t size);
void * remove_block(block * target);
void * coalesce_split(block * target, size_t size);
void coalesce_merge(block * target);
void free(void * ptr);

unsigned long get_data_segment_size();
unsigned long get_data_segment_free_space_size();
