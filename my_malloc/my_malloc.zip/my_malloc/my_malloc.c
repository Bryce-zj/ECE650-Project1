#include "my_malloc.h"

void * allocate_mem(size_t size) {
  // Allocate memory for block.
  block * block_new = sbrk(sizeof(block));
  void * p = sbrk(0);
  // Allocate memory for request size.
  sbrk(size);
  block_new->size = size;
  block_new->next = NULL;
  block_new->prev = NULL;
  total_size += size + sizeof(block);
  return p;
}

void * remove_block(block * target) {
  if (head == NULL) {
    return NULL;
  }
  if (target == head && target == tail) {
    head = NULL;
    tail = NULL;
  }
  else if (target == head) {
    head = target->next;
    head->prev = NULL;
  }
  else if (target == tail) {
    tail = target->prev;
    tail->next = NULL;
  }
  else {
    // If the target block is not head or target, remove it from the list.
    assert(target->next != NULL);
    assert(target->next->prev != NULL);
    target->next->prev = target->prev;
    target->prev->next = target->next;
  }
  target->prev = NULL;
  target->next = NULL;
  free_size -= target->size + sizeof(block);
  // Get the address of current block.
  void * addr = (void *)target;
  return addr + sizeof(block);
}

void * coalesce_split(block * target, size_t size) {
  void * addr = (void *)target;
  block * remain = (block *)(addr + sizeof(block) + size);
  remain->prev = NULL;
  remain->next = NULL;
  remain->size = target->size - size - sizeof(block);
  target->size = size;
  if (target == head && target == tail) {
    head = remain;
    tail = remain;
  }
  else if (target == head) {
    head = remain;
    remain->next = target->next;
    remain->next->prev = remain;
  }
  else if (target == tail) {
    tail = remain;
    remain->prev = target->prev;
    remain->prev->next = remain;
  }
  else {
    assert(target->prev != NULL && target->next != NULL);
    remain->prev = target->prev;
    remain->next = target->next;
    remain->prev->next = remain;
    remain->next->prev = remain;
  }
  target->next = NULL;
  target->prev = NULL;
  free_size -= size + sizeof(block);
  return addr + sizeof(block);
}

void coalesce_merge(block * target) {
  if (target == head && target == tail) {
    return;
  }
  block * next_t = target->next;
  block * prev_t = target->prev;
  if (next_t != NULL) {
    // If two blocks are conncted.
    if ((void *)next_t == (void *)target + sizeof(block) + target->size) {
      target->next = next_t->next;
      if (next_t->next != NULL) {
        target->next->prev = target;
        // next_t->next = NULL;
      }
      else {
        tail = target;
      }
      //next_t->prev = NULL;
      target->size += next_t->size + sizeof(block);
    }
  }
  if (prev_t != NULL) {
    // If two blocks are conncted.
    if ((void *)target == (void *)prev_t + sizeof(block) + prev_t->size) {
      prev_t->next = target->next;
      if (target->next != NULL) {
        prev_t->next->prev = prev_t;
        //target->next = NULL;
      }
      else {
        tail = prev_t;
      }
      //target->prev = NULL;
      prev_t->size += target->size + sizeof(block);
    }
  }
}

void free_general(void * ptr) {
  if (ptr == NULL) {
    return;
  }
  block * target = (block *)(ptr - sizeof(block));
  assert(target != NULL);
  block * cur = head;
  if (head == NULL) {
    head = target;
    tail = target;
    free_size += target->size + sizeof(block);
    return;
  }

  while (cur != NULL && cur < target) {
    cur = cur->next;
  }

  //Add current block to the front of the list.
  if (cur == head) {
    head = target;
    target->next = cur;
    cur->prev = target;
  }
  //Add current block to the end of the list.
  else if (cur == NULL) {
    target->prev = tail;
    tail->next = target;
    tail = target;
  }
  //Add current block to the next.
  else {
    target->next = cur;
    target->prev = cur->prev;
    target->prev->next = target;
    cur->prev = target;
  }

  free_size += target->size + sizeof(block);
  // After freeing the memory, the program should realize coalesce through merging.
  coalesce_merge(target);
}
// First Fit
void * ff_malloc(size_t size) {
  void * p_ff = NULL;
  // If there are no free block, assign new memory.
  if (head == NULL) {
    p_ff = allocate_mem(size);
  }
  else {
    block * cur = head;
    while (cur != NULL) {
      // The current free block is the target one and does not require splitting.
      if (cur->size >= size && cur->size <= size + sizeof(block)) {
        p_ff = remove_block(cur);
        break;
      }
      // Need splitting.
      else if (cur->size > size + sizeof(block)) {
        p_ff = coalesce_split(cur, size);
        break;
      }
      else {
        cur = cur->next;
      }
    }
    if (p_ff == NULL) {
      p_ff = allocate_mem(size);
    }
  }
  return p_ff;
}

void ff_free(void * ptr) {
  free_general(ptr);
}

//Best Fit
void * bf_malloc(size_t size) {
  void * p_bf = NULL;
  if (head == NULL) {
    p_bf = allocate_mem(size);
  }
  else {
    block * cur = head;
    block * target = NULL;
    while (cur != NULL) {
      // A better block is found.
      if (cur->size == size) {
        p_bf = remove_block(cur);
        return p_bf;
      }
      else if ((target == NULL || cur->size < target->size) && cur->size > size) {
        target = cur;
      }
      else {
        cur = cur->next;
      }
    }
    // If no target block is available, request new memory. Else, remove the block from the free list.
    if (target == NULL) {
      p_bf = allocate_mem(size);
    }
    else if (target->size <= size + sizeof(block)) {
      p_bf = remove_block(target);
    }
    else {
      p_bf = coalesce_split(target, size);
    }
  }
  return p_bf;
}

void bf_free(void * ptr) {
  free_general(ptr);
}

unsigned long get_data_segment_size() {
  return total_size;
}

unsigned long get_data_segment_free_space_size() {
  return free_size;
}
